F3            anything-explorer-history.exe
Ctrl-F3       anything-process-manager.exe
Win-r         anything-run.exe
Ctrl-F4       anything-services-manager_xp.exe  (doesn't support win7 vista  )
Alt-Tab       anything-window-switch.exe
